package com.example.aiassistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.ByteArrayOutputStream

/**
 * The core "hands and eyes" of the assistant on Android. Must be enabled
 * manually by the user in Settings > Accessibility > AI Assistant — this
 * cannot be turned on programmatically, by design of the Android platform.
 */
class AssistantAccessibilityService : AccessibilityService() {

    companion object {
        // Lets MainActivity check whether the service is actually running,
        // and call into it once enabled.
        var instance: AssistantAccessibilityService? = null

        // A small allowlist — same philosophy as the desktop version.
        // Add package names for apps you actually use.
        val KNOWN_APPS = mapOf(
            "whatsapp" to "com.whatsapp",
            "chrome" to "com.android.chrome",
            "camera" to "com.android.camera",
            "gallery" to "com.google.android.apps.photos",
            "settings" to "com.android.settings",
            "gmail" to "com.google.android.gm"
        )
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun takeScreenshotPng(onResult: (ByteArray?) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            onResult(null) // needs Android 11+
            return
        }
        takeScreenshot(
            android.view.Display.DEFAULT_DISPLAY,
            mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    val bitmap = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                    val softwareBitmap = bitmap?.copy(Bitmap.Config.ARGB_8888, false)
                    result.hardwareBuffer.close()
                    val out = ByteArrayOutputStream()
                    softwareBitmap?.compress(Bitmap.CompressFormat.PNG, 100, out)
                    onResult(out.toByteArray())
                }
                override fun onFailure(errorCode: Int) = onResult(null)
            }
        )
    }

    fun click(x: Int, y: Int) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun longPress(x: Int, y: Int) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 600))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun swipe(startY: Int, endY: Int) {
        val screenWidth = resources.displayMetrics.widthPixels
        val path = Path().apply {
            moveTo(screenWidth / 2f, startY.toFloat())
            lineTo(screenWidth / 2f, endY.toFloat())
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 300))
            .build()
        dispatchGesture(gesture, null, null)
    }

    /** Types into whichever field currently has input focus. */
    fun typeText(text: String) {
        val focused = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        val arguments = android.os.Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
        }
        focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }

    fun goBack() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome() = performGlobalAction(GLOBAL_ACTION_HOME)

    fun openApp(name: String): Boolean {
        val packageName = KNOWN_APPS[name.lowercase().trim()] ?: return false
        val intent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return true
    }
}
