package com.example.aiassistant

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var voice: VoiceHelper
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        voice = VoiceHelper(this)
        voice.initTts()

        val apiKeyInput = findViewById<EditText>(R.id.apiKeyInput)
        val saveKeyButton = findViewById<Button>(R.id.saveKeyButton)
        val enableServiceButton = findViewById<Button>(R.id.enableServiceButton)
        val listenButton = findViewById<Button>(R.id.listenButton)
        statusText = findViewById(R.id.statusText)

        // First run: ask for the key once, same pattern as the desktop version.
        if (ConfigStore.getApiKey(this) == null) {
            apiKeyInput.visibility = android.view.View.VISIBLE
            saveKeyButton.visibility = android.view.View.VISIBLE
            statusText.text = "Get a free key at aistudio.google.com/apikey"
        }

        saveKeyButton.setOnClickListener {
            val key = apiKeyInput.text.toString().trim()
            if (key.isNotEmpty()) {
                ConfigStore.saveApiKey(this, key)
                apiKeyInput.visibility = android.view.View.GONE
                saveKeyButton.visibility = android.view.View.GONE
                statusText.text = "Saved! You won't be asked again on this phone."
            }
        }

        enableServiceButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1)

        listenButton.setOnClickListener {
            val service = AssistantAccessibilityService.instance
            val apiKey = ConfigStore.getApiKey(this)

            if (service == null) {
                statusText.text = "Enable the Accessibility Service first."
                return@setOnClickListener
            }
            if (apiKey == null) {
                statusText.text = "Enter your API key first."
                return@setOnClickListener
            }

            statusText.text = "Listening..."
            voice.listen(
                onResult = { command -> handleCommand(service, apiKey, command) },
                onError = { statusText.text = "Didn't catch that — try again." }
            )
        }
    }

    private fun handleCommand(service: AssistantAccessibilityService, apiKey: String, command: String) {
        statusText.text = "Heard: \"$command\" — thinking..."

        service.takeScreenshotPng { pngBytes ->
            if (pngBytes == null) {
                statusText.text = "Screenshot needs Android 11+."
                return@takeScreenshotPng
            }

            // Network call off the main thread.
            thread {
                val action = try {
                    GeminiClient.decideAction(apiKey, pngBytes, command)
                } catch (e: Exception) {
                    JSONObject().apply {
                        put("action", "say")
                        put("spoken", "Something went wrong reaching Gemini.")
                        put("language", "en")
                    }
                }
                runOnUiThread { executeAction(service, action) }
            }
        }
    }

    private fun executeAction(service: AssistantAccessibilityService, action: JSONObject) {
        val kind = action.optString("action", "none")
        var spoken = action.optString("spoken", "")
        val language = action.optString("language", "en")

        when (kind) {
            "click" -> service.click(action.optInt("x"), action.optInt("y"))
            "long_press" -> service.longPress(action.optInt("x"), action.optInt("y"))
            "type" -> service.typeText(action.optString("text", ""))
            "swipe_up" -> service.swipe(1500, 300)
            "swipe_down" -> service.swipe(300, 1500)
            "back" -> service.goBack()
            "home" -> service.goHome()
            "open_app" -> {
                val name = action.optString("text", "")
                if (!service.openApp(name)) spoken = "'$name' isn't on my known app list yet."
            }
            "say", "none" -> { /* just speak */ }
        }

        statusText.text = spoken
        if (spoken.isNotBlank()) voice.speak(spoken, language)
    }

    override fun onDestroy() {
        super.onDestroy()
        voice.destroy()
    }
}
