package com.example.aiassistant

import android.content.Context

/**
 * Stores the Google AI API key in local SharedPreferences.
 * Asked for once in MainActivity, then loaded silently on every launch after.
 */
object ConfigStore {
    private const val PREFS = "ai_assistant_prefs"
    private const val KEY_API_KEY = "google_api_key"

    fun getApiKey(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString(KEY_API_KEY, null)
    }

    fun saveApiKey(context: Context, key: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_API_KEY, key).apply()
    }

    fun clearApiKey(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().remove(KEY_API_KEY).apply()
    }
}
