package com.example.aiassistant

import android.content.Context
import android.content.Intent
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Wraps Android's built-in SpeechRecognizer (STT) and TextToSpeech (TTS).
 * Both are free and built into Android — no extra API key needed.
 *
 * Note: Android's on-device recognizer needs a language hint per session
 * (it doesn't auto-detect like the desktop version's multi-try approach).
 * Defaults to English; call setPreferredLanguage() to switch.
 */
class VoiceHelper(private val context: Context) {

    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var preferredLocale = Locale.US // en-US default

    fun setPreferredLanguage(code: String) {
        preferredLocale = when (code) {
            "hi" -> Locale("hi", "IN")
            "bn" -> Locale("bn", "IN")
            else -> Locale.US
        }
    }

    fun initTts(onReady: () -> Unit = {}) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) onReady()
        }
    }

    fun speak(text: String, language: String = "en") {
        val locale = when (language) {
            "hi" -> Locale("hi", "IN")
            "bn" -> Locale("bn", "IN")
            else -> Locale.US
        }
        tts?.language = locale
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    fun listen(onResult: (String) -> Unit, onError: () -> Unit = {}) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError()
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, preferredLocale.toString())
        }

        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: android.os.Bundle) {
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull() ?: ""
                if (text.isNotBlank()) onResult(text) else onError()
            }
            override fun onError(error: Int) = onError()
            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })

        recognizer?.startListening(intent)
    }

    fun destroy() {
        tts?.shutdown()
        recognizer?.destroy()
    }
}
