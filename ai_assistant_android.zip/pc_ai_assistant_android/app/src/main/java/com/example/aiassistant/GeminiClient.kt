package com.example.aiassistant

import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Same system prompt/personality as the Windows version — friendly,
 * multilingual (English/Hindi/Bangla), same action schema.
 */
object GeminiClient {

    private const val MODEL = "gemini-2.5-flash"
    private const val ENDPOINT =
        "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    private val SYSTEM_PROMPT = """
        You control an Android phone on behalf of the user, based on a
        screenshot and a spoken command. Reply with ONLY a JSON object,
        no other text:

        {
          "action": "click" | "long_press" | "type" | "swipe_up" | "swipe_down" | "back" | "home" | "open_app" | "say" | "none",
          "x": <int, only for click/long_press>,
          "y": <int, only for click/long_press>,
          "text": "<string to type, or app name to open>",
          "spoken": "<what to say out loud about this, always filled in>",
          "language": "en" | "hi" | "bn",
          "reasoning": "<one short sentence>"
        }

        Only pick "open_app" for launching apps by common name (e.g.
        "whatsapp", "chrome", "camera", "gallery", "settings").
        Use "say" when you just need to respond verbally with no action.
        Be conservative: if the command is ambiguous or risky (deleting
        things, payments, sending messages), use "say" and ask for
        confirmation instead of acting.

        PERSONALITY — warm, friendly, genuinely helpful, like a capable
        assistant who's also a good friend. Not stiff, not robotic. Keep
        it short and natural, with a little warmth and light humor.

        LANGUAGE — the user may speak English, Hindi, or Bangla. Detect
        which one was used, reply in "spoken" in that same language, and
        set "language" to "en", "hi", or "bn".
    """.trimIndent()

    private val client = OkHttpClient.Builder()
        .callTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * @param screenshotBytes PNG bytes of the current screen (from the
     *   accessibility service's takeScreenshot()).
     * @param spokenCommand the transcribed voice command.
     * @return parsed action as a JSONObject, or a fallback "say" action
     *   if the response couldn't be parsed.
     */
    fun decideAction(apiKey: String, screenshotBytes: ByteArray, spokenCommand: String): JSONObject {
        val imageB64 = Base64.encodeToString(screenshotBytes, Base64.NO_WRAP)

        val body = JSONObject().apply {
            put("system_instruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT)))
            })
            put("contents", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().apply {
                    put(JSONObject().apply {
                        put("inline_data", JSONObject().apply {
                            put("mime_type", "image/png")
                            put("data", imageB64)
                        })
                    })
                    put(JSONObject().put("text", "Command: $spokenCommand"))
                })
            }))
        }

        val request = Request.Builder()
            .url("$ENDPOINT?key=$apiKey")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string() ?: ""
            return parseAction(raw)
        }
    }

    private fun parseAction(rawResponse: String): JSONObject {
        val fallback = JSONObject().apply {
            put("action", "say")
            put("spoken", "Sorry, I didn't quite catch that.")
            put("language", "en")
        }
        return try {
            val envelope = JSONObject(rawResponse)
            var text = envelope
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
                .trim()

            if (text.startsWith("```")) {
                text = text.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            }
            JSONObject(text)
        } catch (e: Exception) {
            fallback
        }
    }
}
