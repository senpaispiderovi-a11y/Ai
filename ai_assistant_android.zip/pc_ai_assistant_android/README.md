# AI Assistant — Android version (build guide)

This is a starter Android Studio project, not a finished polished app.
Same idea as the Windows version — voice in, screen understanding via
Gemini, actions out — adapted to how Android actually works.

## Why there's no ready-made .apk here

Building an installable APK requires Android Studio's build toolchain
(Gradle + Android SDK), which isn't available in the sandbox that
generated this project. You'll build it yourself — takes about 10
minutes with Android Studio installed.

## 1. Build it

1. Install [Android Studio](https://developer.android.com/studio) (free).
2. Open this folder as a project (File > Open > select this folder).
3. Let it sync Gradle (first time takes a few minutes, needs internet).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The APK lands in `app/build/outputs/apk/debug/app-debug.apk`.

## 2. Install it on your phone

- Easiest: with your phone connected via USB and USB debugging enabled,
  hit the green ▶ Run button in Android Studio.
- Or: copy `app-debug.apk` to your phone and open it to install
  (you'll need to allow "install unknown apps" for whichever app you
  used to transfer it — Files, Chrome, etc.).

## 3. First launch

1. Paste your Google AI API key (free at aistudio.google.com/apikey) —
   saved locally, never asked again.
2. Tap "Enable Accessibility Service" — this opens Android's own
   settings screen; find "AI Assistant" in the list and turn it on.
   Android will show a serious-sounding warning here. That's normal —
   it's warning you about exactly what you're intentionally enabling.
3. Tap "🎤 Talk to Assistant" and speak a command.

## What it can do

- Tap, long-press, type into focused fields, swipe up/down, back/home
- Open apps from a small allowlist (`KNOWN_APPS` in
  `AssistantAccessibilityService.kt`) — add package names for apps you
  actually use
- Listen and respond in English, Hindi, or Bangla (set explicitly per
  session — Android's built-in recognizer needs a language hint, unlike
  the desktop version's "try all three" approach)
- Speak back using Android's built-in text-to-speech

## What's different from the Windows version, and why

- **No auto-language-detection on listening.** Android's SpeechRecognizer
  needs one language set per session rather than trying several. You can
  wire a language-picker into the UI, or just default to whichever
  language you use most (`VoiceHelper.setPreferredLanguage()`).
- **No copy/paste/create-folder actions yet.** Android's permission model
  for clipboard and file system access is stricter and more fiddly than
  Windows — clipboard access from a background context is restricted,
  and folder creation needs Storage Access Framework consent per-folder.
  Doable, just left out of this first pass to keep it buildable.
- **Screenshot needs Android 11+.** `takeScreenshot()` for accessibility
  services was added in API 30.

## Serious things to know before using this

- **This is functionally the same permission profile as Android banking
  malware.** An Accessibility Service that can read your screen and
  simulate taps/typing is exactly what that category of malware abuses.
  That's not a reason not to build a personal tool — plenty of legitimate
  accessibility and automation apps use this API — but:
  - **Never distribute the built APK to anyone else.** Sideloading it on
    your own device, for yourself, is one thing; handing it to someone
    else is functionally handing them a remote-control tool for their
    phone.
  - **Google Play will not accept an app like this** — this pattern is
    against their policies for good reason.
  - **Play Protect / antivirus will likely flag the APK when sideloaded.**
    Expected, not a bug.
- The `open_app` list is intentionally a small allowlist — extend it
  deliberately, don't make it launch arbitrary packages.
- No confirmation step before acting and no undo — same caveat as the
  desktop version. Consider adding a confirm-before-risky-action check
  before relying on this for anything that matters (sending messages,
  payments, deleting things).
- Gemini API calls happen over your phone's internet connection and are
  billed to your account past the free tier — same ~10 RPM free-tier
  cap as the desktop version applies here too.
